<h1>Blog Posts</h1>

@foreach ($posts as $post)
    <p>{{ $post }}</p>
@endforeach